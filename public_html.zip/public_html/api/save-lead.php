<?php
// ============================================
// Lead Capture API — PredictCollege.in
// Upload to: /api/save-lead.php on Hostinger
// ============================================

// ── CORS Headers ──
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: https://predictcollege.in');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// Only allow POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// ┌─────────────────────────────────────────┐
// │  UPDATE THESE WITH YOUR HOSTINGER       │
// │  DATABASE CREDENTIALS                   │
// └─────────────────────────────────────────┘
$DB_HOST = 'localhost';              // Usually 'localhost' on Hostinger
$DB_NAME = '';                       // TODO: Set your database name
$DB_USER = '';                       // TODO: Set your database username
$DB_PASS = '';                       // TODO: Set your database password

try {
    // Read JSON body
    $rawInput = file_get_contents('php://input');
    $data = json_decode($rawInput, true);

    if (!$data) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => 'Invalid JSON payload']);
        exit;
    }

    // Extract fields
    $name             = trim($data['name'] ?? '');
    $phone            = trim($data['phone'] ?? '');
    $percentile       = $data['percentile'] ?? null;
    $admission_type   = trim($data['admission_type'] ?? '');
    $preferred_branch = trim($data['preferred_branch'] ?? '');
    $city             = trim($data['city'] ?? '');

    // ── Validation ──
    $errors = [];

    if (empty($name) || strlen($name) > 100) {
        $errors[] = 'Name is required (max 100 characters)';
    }

    if (empty($phone) || !preg_match('/^[6-9]\d{9}$/', $phone)) {
        $errors[] = 'A valid 10-digit Indian phone number is required';
    }

    if ($percentile === null || !is_numeric($percentile) || $percentile < 0 || $percentile > 100) {
        $errors[] = 'Percentile must be a number between 0 and 100';
    }

    $validAdmTypes = ['Engineering (PCM)', 'Pharmacy (PCB)'];
    if (empty($admission_type) || !in_array($admission_type, $validAdmTypes)) {
        $errors[] = 'Please select a valid admission type';
    }

    if (empty($city)) {
        $errors[] = 'City/Region is required';
    }

    if (!empty($errors)) {
        http_response_code(422);
        echo json_encode(['success' => false, 'message' => implode('. ', $errors)]);
        exit;
    }

    // ── Database Connection ──
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );

    // ── Insert Lead ──
    $stmt = $pdo->prepare(
        'INSERT INTO leads (name, phone, percentile, admission_type, preferred_branch, city, ip_address, user_agent)
         VALUES (:name, :phone, :percentile, :adm, :branch, :city, :ip, :ua)'
    );

    $stmt->execute([
        ':name'       => $name,
        ':phone'      => $phone,
        ':percentile' => (float) $percentile,
        ':adm'        => $admission_type,
        ':branch'     => $preferred_branch ?: null,
        ':city'       => $city,
        ':ip'         => $_SERVER['REMOTE_ADDR'] ?? null,
        ':ua'         => $_SERVER['HTTP_USER_AGENT'] ?? null,
    ]);

    http_response_code(201);
    echo json_encode(['success' => true, 'message' => 'Lead saved successfully']);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Database error. Please try again later.']);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Server error. Please try again later.']);
}
