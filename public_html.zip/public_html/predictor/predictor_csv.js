const CSV_PATH = "data.csv";
const PER = 25;
const ROUNDS = {
  latest: "Latest available cutoff",
  round1: "Round 1",
  round2: "Round 2",
  round3: "Round 3",
  round4: "Round 4",
};
const HOT = ["computer", "information technology", "artificial intelligence", "machine learning", "data science", "cyber", "iot", "internet of things", "robotics", "vlsi"];
const BRANCH_GROUPS = [
  { id: "ai", label: "Artificial Intelligence (All)", terms: ["artificial intelligence", "ai "] },
  { id: "data_science", label: "Data Science (All)", terms: ["data science"] },
  { id: "ai_ds", label: "AI & Data Science (Combined)", terms: ["artificial intelligence (ai) and data science", "artificial intelligence and data science", "artificial intelligence & data science", "ai and data science", "ai & data science"] },
  { id: "cs", label: "Computer Science / Computer Engineering (All)", terms: ["computer engineering", "computer science", "computer technology", "software engineering", "computer application"] },
  { id: "it", label: "Information Technology (All)", terms: ["information technology"] },
  { id: "cyber", label: "Cyber Security (All)", terms: ["cyber"] },
  { id: "iot", label: "Internet of Things / IoT (All)", terms: ["iot", "internet of things", "industrial iot"] },
  { id: "robotics", label: "Robotics / Automation (All)", terms: ["robotics", "automation"] },
  { id: "electronics", label: "Electronics / ENTC / VLSI (All)", terms: ["electronics", "telecommunication", "communication", "vlsi"] },
  { id: "electrical", label: "Electrical Engineering (All)", terms: ["electrical"] },
  { id: "mechanical", label: "Mechanical / Mechatronics / Automobile (All)", terms: ["mechanical", "mechatronics", "automobile", "rail"] },
  { id: "civil", label: "Civil / Structural / Infrastructure (All)", terms: ["civil", "structural", "infrastructure", "environmental"] },
  { id: "chemical", label: "Chemical / Petrochemical / Pharmaceutical Tech (All)", terms: ["chemical", "petro chemical", "pharmaceutical"] },
  { id: "bio", label: "Biomedical / Biotechnology (All)", terms: ["bio medical", "biomedical", "bio technology"] },
  { id: "food", label: "Food Technology (All)", terms: ["food"] },
  { id: "textile", label: "Textile Technology (All)", terms: ["textile", "fibres", "man made textile"] },
  { id: "plastic_polymer", label: "Plastic / Polymer Technology (All)", terms: ["plastic", "polymer"] },
  { id: "oil_paint", label: "Oil / Paints / Surface Coating (All)", terms: ["oil", "paint", "coating", "waxes", "oleochemicals"] },
  { id: "production", label: "Production / Manufacturing (All)", terms: ["production", "manufacturing"] },
  { id: "instrumentation", label: "Instrumentation (All)", terms: ["instrumentation"] },
  { id: "safety_fire", label: "Fire / Safety Engineering (All)", terms: ["fire", "safety"] },
];

let db = null;
let all = [];
let filtered = [];
let pg = 1;
let mobOpen = true;
let drawerOpen = false;
let saved = JSON.parse(localStorage.getItem("pc_saved") || "{}");
const scoreMode = { mode: "percentile" };

const $ = (id) => document.getElementById(id);
const clean = (v) => String(v ?? "").trim();
const esc = (v) => String(v ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const uniq = (rows, key) => [...new Set(rows.map((r) => clean(r[key])).filter(Boolean))].sort((a, b) => a.localeCompare(b));
const opt = (v) => `<option value="${esc(v)}">${esc(v)}</option>`;
const branchGroup = (id) => BRANCH_GROUPS.find((g) => g.id === id);

function parseScore(v) {
  const s = clean(v);
  if (!s || s === "-") return null;
  const n = parseFloat(s.replace(/%ile/i, "").replace("%", ""));
  return Number.isFinite(n) ? n : null;
}
function parseRank(v) {
  const n = parseInt(clean(v).replace(/,/g, ""), 10);
  return Number.isFinite(n) && n > 0 ? n : null;
}
function parseCsv(text) {
  const lines = text.split(/\r?\n/);
  if (!lines.length) return [];
  const headers = lines[0].split(',').map(h => h.trim());
  const rows = [];
  for(let i = 1; i < lines.length; i++) {
    const line = lines[i];
    if (!line) continue;
    let row = [], start = 0, inQuote = false;
    for (let j = 0; j < line.length; j++) {
      if (line[j] === '"') inQuote = !inQuote;
      else if (line[j] === ',' && !inQuote) {
        let val = line.substring(start, j);
        if (val.charCodeAt(0) === 34 && val.charCodeAt(val.length - 1) === 34) {
          val = val.substring(1, val.length - 1).replace(/""/g, '"');
        }
        row.push(val);
        start = j + 1;
      }
    }
    let val = line.substring(start);
    if (val.charCodeAt(0) === 34 && val.charCodeAt(val.length - 1) === 34) {
      val = val.substring(1, val.length - 1).replace(/""/g, '"');
    }
    row.push(val);
    let obj = {}, hasData = false;
    for (let j = 0; j < headers.length; j++) {
        let v = row[j] ?? "";
        if (v) hasData = true;
        obj[headers[j]] = v;
    }
    if (hasData) rows.push(obj);
  }
  return rows;
}
async function loadData() {
  if (db) return db; // already loaded this session — reuse in memory

  // If testing locally via file://, browsers block fetch() by default
  if (window.location.protocol === "file:") {
    throw new Error("You opened this page directly as a local file (file://). Browsers block automated data loading for security reasons when opened without a web server. Please test on your web hosting or use the button below to pick data.csv.");
  }

  // Try multiple candidate paths (relative and absolute, .csv and .txt)
  const candidatePaths = [
    "data.csv",
    "data.txt",
    "/predictor/data.csv",
    "/predictor/data.txt"
  ];

  let lastStatus = "";

  for (const path of candidatePaths) {
    try {
      const res = await fetch(path);
      if (res.ok) {
        const text = await res.text();
        if (text && text.trim().length > 100) {
          db = parseCsv(text).map((r, i) => ({ ...r, _id: i }));
          return db;
        }
      } else {
        lastStatus = `HTTP ${res.status}`;
      }
    } catch (networkErr) {
      lastStatus = networkErr.message || "Network error";
    }
  }

  throw new Error(`Could not load data (${lastStatus}). Please ensure data.csv or data.txt is uploaded to the /predictor/ folder on your server.`);
}
function cutoff(row, isRank, round) {
  const kind = isRank ? "rank" : "score";
  const parse = isRank ? parseRank : parseScore;
  if (round !== "latest") return parse(row[`${round}_${kind}`]);
  for (let i = 4; i >= 1; i--) {
    const value = parse(row[`round${i}_${kind}`]);
    if (value !== null) return value;
  }
  return null;
}
function cutoffRound(row, isRank, round) {
  if (round !== "latest") return ROUNDS[round];
  const kind = isRank ? "rank" : "score";
  const parse = isRank ? parseRank : parseScore;
  for (let i = 4; i >= 1; i--) if (parse(row[`round${i}_${kind}`]) !== null) return `Round ${i}`;
  return "Round";
}
function chance(input, cv, isRank) {
  const diff = isRank ? cv - input : input - cv;
  return diff >= (isRank ? 5000 : 5) ? "safe" : diff >= 0 ? "moderate" : "reach";
}
function fmt(v, isRank) { return isRank ? v.toLocaleString("en-IN") : v.toFixed(4); }
function fmtDiff(v, isRank) { return `${v >= 0 ? "+" : ""}${isRank ? v.toLocaleString("en-IN") : v.toFixed(2) + "%ile"}`; }
function chanceText(c) { return c === "safe" ? "Safe" : c === "moderate" ? "Moderate" : "Reach"; }
function chanceClass(c) { return c === "safe" ? "bs" : c === "moderate" ? "bm" : "br"; }
function highDemand(course) { return HOT.some((term) => clean(course).toLowerCase().includes(term)); }
function courseInGroup(course, group) {
  const c = clean(course).toLowerCase();
  return group.terms.some((term) => c.includes(term));
}
function buildBranchOptions(courses) {
  const covered = new Set();
  const grouped = BRANCH_GROUPS.map((group) => {
    const matches = courses.filter((course) => courseInGroup(course, group));
    matches.forEach((course) => covered.add(course));
    return matches.length ? `<option value="grp:${esc(group.id)}">${esc(group.label)}</option>` : "";
  }).join("");
  const other = courses
    .filter((course) => !covered.has(course))
    .map((course) => `<option value="course:${esc(course)}">${esc(course)}</option>`)
    .join("");
  return grouped + other;
}

function rebuildForm(rows) {
  // Don't gate on .fbody — just populate each select directly by ID
  const sets = { category: new Set(), description: new Set(), exam: new Set(), university: new Set(), location: new Set(), course: new Set() };
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    if (r.category) sets.category.add(clean(r.category));
    if (r.description) sets.description.add(clean(r.description));
    if (r.exam) sets.exam.add(clean(r.exam));
    if (r.university) sets.university.add(clean(r.university));
    if (r.location) sets.location.add(clean(r.location));
    if (r.course) sets.course.add(clean(r.course));
  }
  const uCat = Array.from(sets.category).sort((a,b)=>a.localeCompare(b)).map(opt).join("");
  const uDesc = Array.from(sets.description).sort((a,b)=>a.localeCompare(b)).map(opt).join("");
  const uExam = Array.from(sets.exam).sort((a,b)=>a.localeCompare(b)).map(opt).join("");
  const uUniv = Array.from(sets.university).sort((a,b)=>a.localeCompare(b)).map(opt).join("");
  const uLoc = Array.from(sets.location).sort((a,b)=>a.localeCompare(b)).map(opt).join("");
  const courses = Array.from(sets.course).sort((a,b)=>a.localeCompare(b));

  const catSelect = document.getElementById("category-select");
  if (catSelect) catSelect.innerHTML = `<option value="">Select Category</option>${uCat}`;

  const seatSelect = document.getElementById("seat-type-select");
  if (seatSelect) seatSelect.innerHTML = `<option value="">All Seat Types</option>${uDesc}`;

  const examSelect = document.getElementById("exam-select");
  if (examSelect) examSelect.innerHTML = `<option value="">All Exams</option>${uExam}`;

  const courseSelect = document.getElementById("course-select");
  if (courseSelect) courseSelect.innerHTML = `<option value="">All Branches</option>${buildBranchOptions(courses)}`;

  const uniSelect = document.getElementById("university-select");
  if (uniSelect) uniSelect.innerHTML = `<option value="">All Universities</option>${uUniv}`;

  const locSelect = document.getElementById("location-select");
  if (locSelect) locSelect.innerHTML = `<option value="">All Locations</option>${uLoc}`;
}
async function initPredictor() {
  const panel = $("results-panel");

  // Show loading status inside the filter card too, so it's visible
  const catSelect = document.getElementById("category-select");
  if (catSelect) catSelect.innerHTML = '<option value="">⏳ Loading data…</option>';

  if (panel) panel.innerHTML = '<div class="ph"><div class="ei">⏳</div><h3>Loading cutoff data…</h3><p>Fetching college data — this may take a few seconds on first load.</p></div>';

  try {
    const rows = await loadData();

    if (!rows || rows.length === 0) {
      if (catSelect) catSelect.innerHTML = '<option value="">❌ No data loaded</option>';
      if (panel) panel.innerHTML = '<div class="empt"><div class="ei">!</div><h3>No data found</h3><p>The data file loaded but contained no records. Please re-upload data.csv.</p></div>';
      return;
    }

    rebuildForm(rows);

    if (panel) panel.innerHTML = '<div class="ph"><div class="ei">✓</div><h3>Ready to predict</h3><p>Enter your percentile (or rank), select your category and CAP round, then click <b>Predict Colleges</b>.</p></div>';
  } catch (e) {
    console.error(e);
    if (catSelect) catSelect.innerHTML = `<option value="">❌ Could not load data</option>`;
    if (panel) {
      panel.innerHTML = `<div class="empt"><div class="ei">!</div><h3>Could not load data</h3><p style="margin-bottom:16px;">${esc(e.message || 'An unexpected error occurred.')}</p><div style="background:var(--surface);padding:14px;border-radius:10px;border:1px dashed var(--border);display:inline-block;text-align:left;"><label style="display:block;font-weight:600;margin-bottom:6px;font-size:13px;">📁 Or load data.csv manually from your folder:</label><input type="file" id="manual-file-input" accept=".csv,.txt" style="font-size:12px;" onchange="handleManualFile(this)"></div></div>`;
    }
  }

  updateSavedCount();
  renderShortlist();
}

function handleManualFile(input) {
  const file = input && input.files && input.files[0];
  if (!file) return;
  const panel = $("results-panel");
  if (panel) panel.innerHTML = '<div class="ph"><div class="ei">⏳</div><h3>Reading file…</h3><p>Processing ' + esc(file.name) + '…</p></div>';
  const reader = new FileReader();
  reader.onload = function(evt) {
    try {
      const text = evt.target.result;
      db = parseCsv(text).map((r, i) => ({ ...r, _id: i }));
      rebuildForm(db);
      if (panel) panel.innerHTML = '<div class="ph"><div class="ei">✓</div><h3>Ready to predict</h3><p>Loaded ' + db.length.toLocaleString() + ' records. Enter your score and click <b>Predict Colleges</b>.</p></div>';
      toast('Loaded ' + db.length.toLocaleString() + ' records');
    } catch(err) {
      console.error(err);
      toast('Failed to parse file: ' + err.message);
    }
  };
  reader.readAsText(file);
}
function switchTab(tab) {
  scoreMode.mode = tab;
  document.querySelectorAll(".tab-pill").forEach((b, i) => b.classList.toggle("active", (i === 0 && tab === "percentile") || (i === 1 && tab === "rank")));
  if ($("percentile-group")) $("percentile-group").style.display = tab === "percentile" ? "" : "none";
  if ($("rank-group")) $("rank-group").style.display = tab === "rank" ? "" : "none";
}
function toggleMobForm() {
  mobOpen = !mobOpen;
  $("fcard")?.classList.toggle("mob-hide", !mobOpen);
  if ($("mfl")) $("mfl").textContent = mobOpen ? "Hide Filters" : "Show Filters";
}
function toast(msg) {
  const t = $("toast");
  if (!t) return;
  t.textContent = msg;
  t.className = "toast on";
  clearTimeout(t._t);
  t._t = setTimeout(() => t.className = "toast", 3000);
}
function toggleTheme() {
  const dark = document.documentElement.getAttribute("data-theme") === "dark";
  document.documentElement.setAttribute("data-theme", dark ? "light" : "dark");
}
function toggleDrawer() {
  drawerOpen = !drawerOpen;
  $("drawer")?.classList.toggle("open", drawerOpen);
  $("drawer-overlay")?.classList.toggle("open", drawerOpen);
  $("hamburger")?.classList.toggle("open", drawerOpen);
  document.body.style.overflow = drawerOpen ? "hidden" : "";
}
function showTab(tab) {
  document.querySelectorAll(".tab-panel").forEach((p) => p.classList.remove("active"));
  $("tab-" + tab)?.classList.add("active");
}
function handleRoute() { showTab("predictor"); }
function openBlog(id) { window.location.href = "/blog/" + id + "/"; }
function subscribeAlert() { toast("Alerts are not connected in this local CSV version."); }
function filterByQuery(pct) { if ($("percentile-input")) $("percentile-input").value = pct; switchTab("percentile"); runPrediction(); }
function updateBranchOptions() {}

async function runPrediction() {
  const isRank = scoreMode.mode === "rank";
  const input = isRank ? parseRank($("rank-input")?.value) : parseFloat($("percentile-input")?.value);
  if (isRank && !input) return toast("Enter a valid rank");
  if (!isRank && (!Number.isFinite(input) || input < 0 || input > 100)) return toast("Enter a valid percentile");
  const btn = $("predict-btn"), txt = $("btn-text");
  if (btn) btn.disabled = true;
  if (txt) txt.textContent = "Predicting...";
  try {
    const rows = await loadData();
    const f = {
      category: $("category-select")?.value || "",
      seat_type: $("seat-type-select")?.value || "",
      exam: $("exam-select")?.value || "",
      round: $("round-select")?.value || "latest",
      course: $("course-select")?.value || "",
      university: $("university-select")?.value || "",
      location: $("location-select")?.value || "",
      chance: $("chance-filter")?.value || "",
    };
    all = [];
    for (const r of rows) {
      if (f.category && clean(r.category) !== f.category) continue;
      if (f.seat_type && clean(r.description) !== f.seat_type) continue;
      if (f.exam && clean(r.exam) !== f.exam) continue;
      if (f.course) {
        if (f.course.startsWith("grp:")) {
          const group = branchGroup(f.course.slice(4));
          if (!group || !courseInGroup(r.course, group)) continue;
        } else if (f.course.startsWith("course:")) {
          if (clean(r.course) !== f.course.slice(7)) continue;
        }
      }
      if (f.university && clean(r.university) !== f.university) continue;
      if (f.location && clean(r.location) !== f.location) continue;
      const cv = cutoff(r, isRank, f.round);
      if (cv === null) continue;
      const diff = isRank ? cv - input : input - cv;
      const ch = chance(input, cv, isRank);
      if (f.chance && ch !== f.chance) continue;
      if (ch === "reach" && ((!isRank && Math.abs(diff) > 10) || (isRank && Math.abs(diff) > 20000))) continue;
      all.push({
        college: clean(r.college_name), location: clean(r.location), course: clean(r.course), category: clean(r.category),
        seat: clean(r.seat_type), description: clean(r.description), exam: clean(r.exam), university: clean(r.university),
        cv, diff, ch, isRank, round: cutoffRound(r, isRank, f.round), hot: highDemand(r.course),
      });
    }
    all.sort((a, b) => b.diff - a.diff || a.college.localeCompare(b.college));
    filtered = [...all];
    pg = 1;
    render(filtered);
    toast(`${all.length} colleges found`);
    if (window.innerWidth < 860) {
      mobOpen = false;
      $("fcard")?.classList.add("mob-hide");
      if ($("mfl")) $("mfl").textContent = "Show Filters";
    }
  } catch (e) {
    console.error(e);
    toast("Failed to load cutoff CSV");
  } finally {
    if (btn) btn.disabled = false;
    if (txt) txt.textContent = "Predict Colleges";
  }
}
function filterResults() {
  const q = clean($("si")?.value).toLowerCase();
  filtered = q ? all.filter((r) => [r.college, r.course, r.university, r.location, r.seat].some((v) => v.toLowerCase().includes(q))) : [...all];
  pg = 1;
  render(filtered);
}
function sortResults() {
  const s = $("ss")?.value || "diff-desc";
  filtered.sort((a, b) => s === "cutoff-desc" ? b.cv - a.cv : s === "cutoff-asc" ? a.cv - b.cv : s === "name-asc" ? a.college.localeCompare(b.college) : b.diff - a.diff);
  pg = 1;
  render(filtered);
}
function render(data) {
  const panel = $("results-panel");
  if (!panel) return;
  if (!data.length) {
    panel.innerHTML = '<div class="empt"><div class="ei">?</div><h3>No colleges found</h3><p>Try a broader category, course, location, or chance filter.</p></div>';
    return;
  }
  const isRank = data[0].isRank;
  const total = Math.ceil(data.length / PER);
  const pageRows = data.slice((pg - 1) * PER, pg * PER);
  let rows = "", cards = "";
  for (const r of pageRows) {
    const ck = chanceClass(r.ch);
    const sk = `${r.college}||${r.course}||${r.seat}`;
    const displaySeat = r.description || r.seat;
    const save = `<button class="save-btn${saved[sk] ? " saved" : ""}" data-skey="${esc(sk)}" onclick='toggleSave(${JSON.stringify(sk)},${JSON.stringify(r.college)},${JSON.stringify(r.course)},${JSON.stringify(displaySeat)})'>${saved[sk] ? "♥" : "♡"}</button>`;
    const chips = `<span class="chip cg">${esc(r.course)}</span><span class="chip cblue">${esc(r.category)}</span><span class="chip cg">${esc(displaySeat)}</span>${r.hot ? '<span class="chip cfire">High Demand</span>' : ""}`;
    rows += `<tr><td><div class="cname">${esc(r.college)}</div><div class="rmeta">${chips}</div></td><td><div class="chip cblue" style="margin-bottom:4px">${esc(r.university || "-")}</div><div class="chip cg">${esc(r.location || "-")}</div></td><td><span class="cv">${fmt(r.cv, isRank)}</span><span class="cu">${isRank ? " rank" : "%ile"}</span><div class="rmeta">${esc(r.round)}</div></td><td><span class="${r.diff >= 0 ? "dp" : "dn"}">${fmtDiff(r.diff, isRank)}</span></td><td><span class="badge ${ck}">${chanceText(r.ch)}</span></td><td>${save}</td></tr>`;
    cards += `<div class="card"><div class="ctop"><div><div class="ccard-name">${esc(r.college)}</div><div class="rmeta" style="margin-top:6px">${chips}</div></div>${save}</div><div class="rmeta" style="margin-bottom:8px"><span class="chip cblue">${esc(r.university || "-")}</span><span class="chip cg">${esc(r.location || "-")}</span></div><div class="cstats"><div class="cstat"><div class="cstat-v">${fmt(r.cv, isRank)}<span style="font-size:10px;color:var(--muted2)">${isRank ? " rank" : "%ile"}</span></div><div class="cstat-l">${esc(r.round)}</div></div><div class="cstat"><div class="cstat-v ${r.diff >= 0 ? "dp" : "dn"}">${fmtDiff(r.diff, isRank)}</div><div class="cstat-l">Buffer</div></div><span class="badge ${ck}">${chanceText(r.ch)}</span></div></div>`;
  }
  let pgn = "";
  if (total > 1) {
    pgn = `<div class="pgn"><button class="pg" onclick="goPage(${pg - 1})" ${pg === 1 ? "disabled" : ""}>&lt;</button><span class="pgi">Page ${pg} of ${total} · ${data.length} total</span><button class="pg" onclick="goPage(${pg + 1})" ${pg === total ? "disabled" : ""}>&gt;</button></div>`;
  }
  panel.innerHTML = `<div class="res-bar"><div><div class="res-title">Results</div><div id="rc" class="res-meta">${data.length} result${data.length !== 1 ? "s" : ""}</div></div><div class="res-acts"><input class="si" id="si" placeholder="Search college, course, location..." oninput="filterResults()"><select class="ss" id="ss" onchange="sortResults()"><option value="diff-desc">Best Match</option><option value="cutoff-desc">Cutoff ↓</option><option value="cutoff-asc">Cutoff ↑</option><option value="name-asc">A → Z</option></select></div></div><div class="legend"><span class="li"><span class="ld" style="background:var(--green)"></span>Safe</span><span class="li"><span class="ld" style="background:#d97706"></span>Moderate</span><span class="li"><span class="ld" style="background:var(--red)"></span>Reach</span><span class="lsep"></span><span class="li" style="color:var(--accent);font-weight:700">High Demand</span></div><div class="tblw"><table><thead><tr><th>College / Course</th><th>University / Location</th><th>Cutoff</th><th>Buffer</th><th>Prediction</th><th>Save</th></tr></thead><tbody>${rows}</tbody></table></div><div class="cards">${cards}</div>${pgn}`;
}
function goPage(p) {
  const total = Math.ceil(filtered.length / PER);
  if (p < 1 || p > total) return;
  pg = p;
  render(filtered);
}
function toggleSave(sk, college, branch, stream) {
  if (saved[sk]) { delete saved[sk]; toast("Removed"); }
  else { saved[sk] = { college, branch, stream, savedAt: new Date().toLocaleDateString("en-IN") }; toast("Saved"); }
  localStorage.setItem("pc_saved", JSON.stringify(saved));
  updateSavedCount();
  renderShortlist();
  render(filtered);
}
function updateSavedCount() {
  const cnt = Object.keys(saved).length;
  if ($("sc")) { $("sc").textContent = cnt; $("sc").style.display = cnt ? "inline-block" : "none"; }
  if ($("drawer-count")) $("drawer-count").textContent = `${cnt} college${cnt === 1 ? "" : "s"} saved`;
}
function renderShortlist() {
  const body = $("sl-body");
  if (!body) return;
  const keys = Object.keys(saved);
  if (!keys.length) {
    body.innerHTML = '<div class="ph"><div class="ei">♡</div><p>No colleges saved yet.<br>Use the ♡ button in results.</p></div>';
    return;
  }
  body.innerHTML = keys.map((k) => {
    const s = saved[k];
    return `<div class="sl-item"><div class="sli-info"><div class="sli-name">${esc(s.college)}</div><div class="sli-branch">${esc(s.branch)} · ${esc(s.stream)}${s.savedAt ? ` <span style="color:var(--muted2);font-size:10px">· saved ${esc(s.savedAt)}</span>` : ""}</div></div><button class="sl-rm" onclick='toggleSave(${JSON.stringify(k)},${JSON.stringify(s.college)},${JSON.stringify(s.branch)},${JSON.stringify(s.stream)})'>×</button></div>`;
  }).join("");
}
function clearShortlist() {
  saved = {};
  localStorage.removeItem("pc_saved");
  updateSavedCount();
  renderShortlist();
  render(filtered);
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", initPredictor);
} else {
  initPredictor();
}
window.addEventListener("popstate", handleRoute);
Object.assign(window, {
  switchTab,
  toggleMobForm,
  toggleTheme,
  toggleDrawer,
  showTab,
  handleRoute,
  openBlog,
  subscribeAlert,
  filterByQuery,
  updateBranchOptions,
  runPrediction,
  filterResults,
  sortResults,
  goPage,
  toggleSave,
  renderShortlist,
  clearShortlist,
  handleManualFile,
});
